import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const inicioScreen(),
    );
  }
}

class Pessoa{
  String nome;
  String senha;

  Pessoa(this.nome,this.senha);
}

List banco = [
  Pessoa("rm94947", "014789"),

];


class inicioScreen extends StatefulWidget {
  const inicioScreen({super.key});

  @override
  State<inicioScreen> createState() => _inicioScreenState();
}

class _inicioScreenState extends State<inicioScreen> {
  TextEditingController nomeController = TextEditingController();
  TextEditingController senhaController = TextEditingController();
  String errorMessage = "";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: 450,
          height: 650,
          color: Colors.grey,
          child: Column(children: [
           Text("Log in",
            style:TextStyle(
            fontSize: 50,
            
            )
           ),
           
            Column(
              children: [
                TextField(controller: nomeController,
                decoration: InputDecoration(label: Text("Digite seu usuario"),
                border: OutlineInputBorder(),
                
                ),
                ),
                TextField(controller: senhaController,
                decoration: InputDecoration(label: Text("Digite a senha"),
                border: OutlineInputBorder(),
                
                ),
                ),
                ElevatedButton(onPressed: (){login(nomeController.text, senhaController.text);}, child: Text("Logar")),
                ElevatedButton(onPressed: (){Navigator.push(context, MaterialPageRoute(builder: (context)=>RgisterPage()));},
                 child: Text("Não tem uma conta? registre-se")),
                Text(errorMessage)
              ],
            )
          ],),
        ),
      ),
    );
  }
  bool login(String nome,String senha){
    bool canLogin = false;
    print("testando todos os logins no banco de dados");
for (var user in banco) {
  if (user.nome == nome && user.senha == senha) {
    canLogin = true;
    print("logou");
    break;
  }else{
    print("nao é igual "+user.nome);
  }
}


    return canLogin;
  }
}

class RgisterPage extends StatefulWidget {
  const RgisterPage({super.key});

  @override
  State<RgisterPage> createState() => _RgisterPageState();
}

class _RgisterPageState extends State<RgisterPage> {
   TextEditingController nomeRegisterController = TextEditingController();
  TextEditingController senhaRegisterController = TextEditingController();
  String errorMessage = "";
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Center(
        child: Container(
          width: 450,
          height: 650,
          color: Colors.grey,
          child: 
          Column(
            children:[
              Row(children: [
                IconButton(onPressed: (){Navigator.pop(context);}, icon: Icon(Icons.arrow_back_ios_new))
              ],),
           Text("Crie sua conta!",
            style:TextStyle(
            fontSize: 50,
            )
           ),
           
            Column(
              children: [
                TextField(controller: nomeRegisterController,
                decoration: InputDecoration(label: Text("Digite seu usuario"),
                border: OutlineInputBorder(),
                
                ),
                ),
                TextField(controller: senhaRegisterController,
                decoration: InputDecoration(label: Text("Digite a senha"),
                border: OutlineInputBorder(),
                
                ),
                ),
                Text(errorMessage),
                ElevatedButton(onPressed: (){setState(() {
                  
                  if (check(nomeRegisterController.text, senhaRegisterController.text)){
                    banco.add(Pessoa(nomeRegisterController.text, senhaRegisterController.text));
                  }
                
                });}, child: Text("Registrar")),
                
              ],
            )
          ],),
        ),
      ),
      
    );
  
  }

    bool containSpecialCharacter(String password){
      bool contains = false;
      List<String> specialChars = [
  "!", "@", "#", "\$", "%", "^", "&", "*", "(", ")", "-", "_",
  "+", "=", "{", "}", "[", "]", "|", "\\", ":", ";", "\"", "'",
  "<", ">", ",", ".", "?", "/", "~", "`"
];
    for (var element in specialChars) {
      if(password.contains(element)){
        contains = true;
        break;
      }else{
        
      }
    }
      print("Contem caracter especial: $contains");
      return contains;
    }

  bool check(String nome, String senha){
    bool checked = false;
    int i = 0;
    if (nome.length<10) {
      errorMessage = "O nome deve ter pelo menos 10 caracteres";
      i++;
    }
    if (senha.length<10) {
      errorMessage = "A senha deve ter pelo menos 10 caracteres";
      i++;
    }
    if (containSpecialCharacter(senha)){
      errorMessage = "A senha não pode ter caracteres especiais";
      i++;
    } 
    if(containSpecialCharacter(nome)){
      errorMessage = "O nome não pode ter caracteres especiais";
      i++;
    }

    if (i == 0) {
      errorMessage = "Conta criada com sucesso!";
      checked = true;
    }
    
        return checked;
      }
}


 