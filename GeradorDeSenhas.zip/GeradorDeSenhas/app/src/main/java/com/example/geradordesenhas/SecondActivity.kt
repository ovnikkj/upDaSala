package com.example.geradordesenhas

import android.content.Intent
import android.os.Bundle
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.geradordesenhas.databinding.ActivitySecondBinding


class SecondActivity : AppCompatActivity() {
    private var tamanho = 4
    private lateinit var binding :ActivitySecondBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)
      binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnConfirmar.setOnClickListener{
    val nextScreen = Intent(this, ThirdActivity::class.java).apply {
        putExtra(ThirdActivity.EXTRA_TAMANHO_SENHA, tamanho)
    }

            startActivity(nextScreen)
        }
        binding.seekBar.setOnSeekBarChangeListener(object : OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
tamanho = progress.coerceAtLeast(minimumValue = 4)
                binding.tvTamanho.text = "Tamanho da senha $tamanho"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {

            }
        })
    }
}