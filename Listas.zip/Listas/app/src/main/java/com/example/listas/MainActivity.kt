package com.example.listas


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.listas.ui.theme.ListasTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ListasTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    startScreen(Modifier.padding(innerPadding))

                }
            }
        }
    }
}


@Composable
fun startScreen(modifier: Modifier){
loginBox()
}

@Preview
@Composable
fun loginBox(){
Box(modifier = Modifier.fillMaxSize()
    .height(450.dp)
    .background(Color.Black)) {
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally
       ) {
        Spacer(Modifier.height(40.dp))
        Text(text="ovni's store", color = Color.White, fontSize = 40.sp, fontFamily = FontFamily.Monospace)
        inputBox("Nome:","Digite seu nome",false)
        inputBox("Senha:","Digite sua senha",true)
        Spacer(Modifier.height(30.dp))
        Button(modifier = Modifier.width(300.dp),onClick = {

        }) {Text(text = "Cadastrar")}
    }
}
}
@Composable
fun inputBox (tittle:String,label:String,sensitiveContent:Boolean){
    var input by rememberSaveable { mutableStateOf("") }
    Spacer(Modifier.height(40.dp))
    Text(text = tittle,color= Color.White)
    if(sensitiveContent){
        TextField(visualTransformation = PasswordVisualTransformation(),value = input, onValueChange = {input = it}, label = { Text(label) })
    }
    else{
        TextField(value = input, onValueChange = {input = it}, label = { Text(label) })
    }

}
