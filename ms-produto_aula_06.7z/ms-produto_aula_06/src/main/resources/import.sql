INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Smart TV', 'Smart TV LG LED 29 polegadas', 2990.0);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Mouse Microsoft', 'Mouse sem fio', 250.0);
INSERT INTO tb_produto (nome, descricao, valor) VALUES ('Teclado Microsoft', 'Teclado sem fio', 278.59);

